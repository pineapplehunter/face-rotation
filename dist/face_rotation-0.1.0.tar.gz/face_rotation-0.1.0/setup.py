# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['face_rotation']

package_data = \
{'': ['*']}

install_requires = \
['h5py>=2.10.0,<3.0.0',
 'matplotlib>=3.2.1,<4.0.0',
 'numpy>=1.18.5,<2.0.0',
 'opencv-python>=4.2.0,<5.0.0',
 'pillow>=7.1.2,<8.0.0',
 'tensorflow>=2.2.0,<3.0.0']

setup_kwargs = {
    'name': 'face-rotation',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Shogo Takata',
    'author_email': 'pineapplehunter.daniel@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
